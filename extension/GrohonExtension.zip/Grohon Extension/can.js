$(".ok2g_v2i6KAtSX08ySuv7").remove();
$('a[href="/learn/design-school"]').remove();
$('a[href="/teams"]').remove();
$("._2wrQ3QQxMpzu105bjNfRim").remove();
$("._2k57_GeORGeXMRz2wk-qNs").remove();
$("._23f99zyGZtlDWreJ5dNkE").remove();
$("._2bpGdX5wP_sxV1BblwpVu8").remove();

//$("span:contains('All publish options')").remove();
$('body').mouseover(function () {
    $(".ok2g_v2i6KAtSX08ySuv7").remove();
    $('a[href="/learn/design-school"]').remove();
    $('a[href="/teams"]').remove();
    $("._2wrQ3QQxMpzu105bjNfRim").remove();
    $("._2k57_GeORGeXMRz2wk-qNs").remove();
    $("._2bpGdX5wP_sxV1BblwpVu8").remove();
    //$("span:contains('All publish options')").remove();
    $("._23f99zyGZtlDWreJ5dNkE").remove();
});

$("._5o3nPw.xmZGLQ.WYbhjg").css("display", "none");

window.setInterval(function(){
    $(".R3lH9w").css("display", "none");
    $(".pvMVEg.RsZ59Q").css("display", "none");
    $(".pvf_dg.DwB3TQ").css("display", "none");
    
}, 100);
