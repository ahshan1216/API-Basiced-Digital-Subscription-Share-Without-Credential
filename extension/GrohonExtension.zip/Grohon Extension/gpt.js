window.setInterval(function(){
    $('[data-testid="profile-button"]').css('display', 'none');

    
}, 100);
