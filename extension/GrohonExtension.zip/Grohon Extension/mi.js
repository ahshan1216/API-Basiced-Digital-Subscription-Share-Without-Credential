$('#id_l').css('display', 'none');

// Alternatively, hide the element with aria-controls='id_d'
$('[aria-controls="id_d"]').css('display', 'none');